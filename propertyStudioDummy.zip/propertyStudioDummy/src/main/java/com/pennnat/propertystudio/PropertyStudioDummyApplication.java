package com.pennnat.propertystudio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PropertyStudioDummyApplication {

	public static void main(String[] args) {
		SpringApplication.run(PropertyStudioDummyApplication.class, args);
	}

}
